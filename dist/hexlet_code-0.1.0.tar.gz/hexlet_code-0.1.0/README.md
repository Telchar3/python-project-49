### Hexlet tests and linter status:
https://asciinema.org/a/mkJRypKQ1QNOpvmGUAjceReaB - brain-games
https://asciinema.org/a/Iw9qWdxRAJdhVhJzUptmo5drt - Brain-even
https://asciinema.org/a/YQgOUvCVWSyI87Fx0p27mKlJX - Brain-calc
https://asciinema.org/a/en55UFr4nZBGkvjFR5j23oWsY - Brain-gcd
https://asciinema.org/a/bIa1yHBEw1UN4TQxuObuVJRHz - Brain-progression
https://asciinema.org/a/lNbRBEtSUmM5mhTsq0vARJSIi - Brain-prime
[![Actions Status](https://github.com/Telchar3/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Telchar3/python-project-49/actions)
